<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once "../connections.php";
require_once "../database/profile.php";
require_once '../vendor/autoload.php';
date_default_timezone_set("Asia/Manila");
$dbUser = new Profile();
function time_ago($timestamp){
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    $minutes = round($seconds / 60);
    $hours = round($seconds / 3600);
    $days = round($seconds / 86400);
    $weeks = round($seconds / 604800);
    $months = round($seconds / 2629440);
    $years = round($seconds / 31553280); 
    if($seconds <= 60){
        return "Just now";
    }
    else if($minutes <= 60){
        if($minutes == 1){
            return "one minute ago";
        }
        else{
            return "$minutes minutes ago";
        }
    }
    else if($hours <= 24){
        if($hours == 1){
            return "an hour ago";
        }
        else{
            return "$hours hrs ago";
        }
    }
    else if($days <= 7){
        if($days == 1){
            return "yesterday";
        }
        else{
            return "$days days ago";
        }
    }
    //4.3 == 52/12
    else if($weeks <= 4.3){
        if($weeks == 1){
            return "a week ago";
        }
        else{
            return "$weeks weeks ago";
        }
    }
    else if($months <= 12){
        if($months == 1){
            return "a month ago";
        }
        else{
            return "$months months ago";
        }
    }
    else{
        if($years == 1){
            return "one year ago";
        }
        else{
            return "$years years ago";
        }
    }
}
if(isset($_POST["getProfileById"])){
    $userId = $_POST["userId"];
    $profileId = $_POST["profileId"];
    $checkIfProfileExist = $dbUser->checkIfProfileExist($profileId);
    $data = $dbUser->getProfileById($profileId);
    //when the user view profile he can edit update
    ?>
    <div class="row justify-content-center">
        <div class="card w-75 shadow-lg card-border">
            <div class="card-body">
                <?php
                if($checkIfProfileExist <= 0){
                    ?>
                    <h1 class="text-center profile-font-color">No profile found.</h1>
                    <?php
                }
                foreach($data as $row){
                    $userImage = $row["user_image"];
                    $userDisplayName = $row["user_display_name"];
                    $userBirthDate = $row["user_birth_date"];
                    $userAge = $row["user_age"];
                    $userPhone = $row["user_phone"];
                    ?>
                    <div class="row justify-content-center">
                        <div class="col-lg mb-3 text-center">
                            <div class="profile-background">
                                <img class="img-fluid profile zoom" src="<?php echo "./images/user/".$userImage; ?>"/>
                                </br>
                                <?php
                                if($userId != 0 && $userId == $profileId){
                                    ?>
                                    <button class="btn btn-primary edit-profile" type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop2">Edit</button>
                                    <?php
                                }
                                ?>
                                
                            </div>

                        </div>
                        <div class="col-lg-4 mb-3 text-center" style="background-color:rgb(208,236,198);">
                            </br>
                            </br>
                            </br>
                            </br>
                            <h3 class="profile-font-color"><?php echo $userDisplayName; ?></h3>
                        </div>
                    </div>
                    <hr>
                    <div class="row justify-content-center">
                        <div class="col-lg mb-3 text-center">
                            <h4 class="profile-font-color">Birthday</h4>
                            <p class="lead profile-font-color"><?php echo $userBirthDate; ?></p>
                        </div>

                        <div class="col-lg mb-3 text-center">
                            <h4 class="profile-font-color">Age</h4>
                        <p class="lead profile-font-color"><?php echo $userAge; ?></p>
                        </div>
                    </div>
                    <hr>
                    <div class="row justify-content-center">
                        <div class="col-lg mb-3 text-center bg-dark">
                        <h4 class="text-white">Contact</h4>
                        <p class="lead text-white"><?php echo $userPhone; ?></p>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
    <?php
}
if(isset($_POST["editProfileById"])){
    $userId = $_POST["userId"];
    $data = $dbUser->getProfileById($userId);
    foreach($data as $row){
        $userImage = $row["user_image"];
        $userDisplayName = $row["user_display_name"];
        $userBirthDate = $row["user_birth_date"];
        $userAge = $row["user_age"];
        $userPhone = $row["user_phone"];
        ?>
        <form class="edit-profile">
            <input class="edit-profile-hidden" type="hidden" name="editProfileHidden" value="false"/>
            <div class="row">
                <div class="col text-center">
                    <img id="myImage" class="img-fluid profile" src="
                    <?php
                    if($userImage != ""){
                        echo "./images/user/$userImage";
                    }
                    else{
                        echo "./images/system/default-profile.png";
                    }
                    ?>
                    "/>
                </div>
            </div>
            <span class = "error-text"><p class="text-center user-image-error"></p></span>
            <div class="row justify-content-center text-center">
                <div class="col text-center">
                    <p class="text-center">
                        <label for="files" class="btn btn-primary text-white mt-2">Upload Profile Picture</label>
                    </p>
                    <input id = "files" type = "file" name = "userImage" style="visibility:hidden;" onchange = "showImage.call(this)"/>
                </div>
            </div>
            <div class="row">
                <div class="col-lg mb-3">
                    <label for="userDisplayName" class="fw-bold mb-3">Display Name</label>
                    <input id="userDisplayName" class="form-control user-display-name" type="text" name="userDisplayName" value="<?php echo $userDisplayName; ?>" placeholder="Display Name..."/>
                </div>
            </div>
            <div class="row">
                <div class="col mb-3">
                    <label for="birthDate" class="fw-bold mb-3">Birth Date</label>
                    <div class="input-group date" id="datepicker">
                        
                        <input id="birthDate" type="text" class="form-control date-input" value="<?php echo $userBirthDate; ?>" placeholder="Birth Date" name="userBirthDate" autocomplete="off"/>
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col mb-3">
                    <label for="userPhone" class="fw-bold mb-3">Phone Number</label>
                    <input id="userPhone" class="form-control user-phone" type="text" value="<?php echo $userPhone; ?>" name="userPhone" placeholder="Phone Number..."/>
                </div>
            </div>
            <div class="row">
                <div class="col mb-3 text-center">
                    <button class="btn btn-success update-profile" type="submit">Update</button>
                </div>
            </div>
        </form>
        <?php
    }
}
if(isset($_POST["getExistingPhone"])){
    $userPhone = $_POST["userPhone"];
    $data = $dbUser->getExistingPhoneTwice($userPhone);
    if($data >= 2){
        echo 1;
    }
    else{
        echo 0;
    }
}
if((isset($_POST["editProfileHidden"])) &&($_POST["editProfileHidden"] == "true")){
    $userId = $_POST["userId"];
    $userDisplayName = $_POST["userDisplayName"];
    $userBirthDate = $_POST["userBirthDate"];
    //explode the date to get month, day and year
    $birthDate = explode("/", $userBirthDate);
    //get age from date or userBirthDate
    $userAge = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
        ? ((date("Y") - $birthDate[2]) - 1)
        : (date("Y") - $birthDate[2]));
    $userPhone = $_POST["userPhone"];
    $fileName = $userId;
    if(!empty($_FILES["userImage"]["name"])){
        //directory of your file will go
        $folder = "../images/user/";
        //code for getting temporary file location
        $filetmp = $_FILES["userImage"]["tmp_name"];
        //removing the values until the "." 
        $remove = explode(".",$_FILES["userImage"]["name"]);
        $ext = end($remove);
        
        $fileName = $fileName. ".".$ext;

        //remove old picture from folder
        $data = $dbUser->getUserProfileImageById($userId);
        foreach($data as $row){
            $userImage = $row["user_image"];
            unlink("../images/user/$userImage");
        }
        //move the uploaded image into the folder: resoSys
        move_uploaded_file($filetmp, $folder.$fileName);
    }
    else{
        $fileName = "";
    }

    echo $dbUser->updateUserProfileById($userId,$userDisplayName,$userBirthDate,$userAge,$userPhone,$fileName);
}
if(isset($_POST["displayAllStoryByIdScroll"])){
    $userId = $_POST["userId"];
    $profileId = $_POST["profileId"];
    $start = $_POST["start"];
    $limit = $_POST["limit"];
    if($userId == $profileId){
        $data = $dbUser->displayAllStoryByIdScroll($userId,$start,$limit);
    }
    else{
        $data = $dbUser->displayAllStoryByIdScroll($profileId,$start,$limit);
    }
    foreach($data as $row){
        $userPostId = $row["user_post_id"];
        $userPostImage = $row["user_post_image"];
        $userPostContent = $row["user_post_content"];
        $userPostDate = $row["user_post_date"];
        $userPostTime = $row["user_post_time"];
        $userStoryId = $row["user_story_id"];
        $userImage = $row["user_image"];
        $userDisplayName = $row["user_display_name"];
        $dateTime = $userPostDate. " ".$userPostTime;
        ?>
        <div id="userPostContainer<?php echo $userPostId; ?>" class="row justify-content-center mb-1">
            <div class="col-lg-6">
                <div class="card card-border shadow-lg">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-2">
                                <a class="" href="./profile.php?profile_id=<?php echo $userStoryId; ?>">
                                <img class="profile-image-small" src="<?php echo "./images/user/$userImage"; ?>"/></a>
                            </div>
                            <div class="col">
                                <a class="" href="./profile.php?profile_id=<?php echo $userStoryId; ?>"><h6><?php echo $userDisplayName; ?></h6></a>
                                <a class="" href="./profile.php?profile_id=<?php echo $userStoryId; ?>"><span class = "fs-13"><?php echo time_ago($dateTime); ?></span></a>
                            </div>
                            <?php
                            if($userId == $profileId){
                                ?>
                                <div class="col text-end">
                                    <div class="dropdown">
                                        <button class="btn bg-dark text-white dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                            <span class="iconify" data-icon="entypo:dots-three-horizontal"></span>
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                            <li>
                                                <a id="<?php echo $userPostId; ?>" class="dropdown-item remove-post" href="">Delete post</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <a class="" href="./userpost.php?&post_id=<?php echo $userPostId;?>">
                                    <p class="text-center">
                                        <?php echo $userPostContent; ?>
                                    </p>
                                </a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col text-center">
                                <a class="" href="./userpost.php?&post_id=<?php echo $userPostId;?>">
                                    <img class="user-post-image" src="<?php echo "./images/post/$userPostImage"; ?>"/>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="<?php echo "commentCard".$userPostId; ?>" class="row justify-content-center">
            <div class="col-lg-6 mb-3">
                <div class="card">
                    <div class="card-body">
                        <form class="view-more-comment">
                            <input class="user-post-id" type="hidden" value="<?php echo $userPostId; ?>"/>
                            <div id="<?php echo "h".$userPostId; ?>" class="container">
                                <?php
                                //for user comment
                                $data2 = $dbUser->getPostCommentById($userPostId);
                                foreach($data2 as $row2){
                                    $userCommentId = $row2["user_comment_id"];
                                    $userCommentatorId = $row2["user_id"];
                                    $userComment = $row2["user_comment"];
                                    $userCommentDate = $row2["user_comment_date"];
                                    $userCommentTime = $row2["user_comment_time"];
                                    $userImage2 = $row2["user_image"];
                                    $userDisplayName = $row2["user_display_name"]; 
                                    $dateTime2 = $userCommentDate. " ".$userCommentTime;
                                    ?>
                                    <div id="userCommentId<?php echo $userCommentId; ?>" class="container mb-3 comment-box-color">
                                        <div class="row">
                                            <div class="col-2">
                                                <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId;?>">
                                                <img class="profile-image-small" src="<?php if($userImage2 != ""){echo "./images/user/$userImage2"; }else{echo "./images/system/anonymous.png"; }?>"/></a>
                                            </div>
                                            <div class="col-lg mb-3">
                                                <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId; ?>"><h6><?php if($userCommentatorId != 0){echo $userDisplayName; }else{echo "<span class='text-danger'>Anonymous</span>";}?></h6></a>
                                                <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId; ?>"><span class="badge bg-success"><span class = "fs-13"><?php echo time_ago($dateTime2); ?></span></span></a>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg mb-3">
                                                <p class="text-center">
                                                    <?php echo $userComment; ?>
                                                </p>
                                            </div>
                                            <?php
                                            $userPostUserId = 0;
                                            $data3 = $dbUser->getUserIdByUserPostId($userPostId);
                                            foreach($data3 as $row3){
                                                $userPostUserId = $row3["user_id"];
                                            }
                                            if($userId == $userCommentatorId && $userId != 0 || $userId == $userPostUserId){
                                                ?>
                                                <div class="col text-end">
                                                    <div class="dropdown">
                                                        <button class="btn bg-primary text-white dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <span class="iconify" data-icon="entypo:dots-three-horizontal"></span>
                                                        </button>
                                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                                            <li>
                                                                <form class="remove-comment">
                                                                    <input class="user-comment-id" type="hidden" value="<?php echo $userCommentId; ?>"/>
                                                                    
                                                                <a id="" class="dropdown-item remove-comment">Remove Comment</a>
                                                                </form>
                                                            
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <div id="latestCommentAppend<?php echo $userPostId; ?>" class="container">

                            </div>
                            <div class="container view-more-comment-container">
                                <?php
                                    //here na me
                                    $getPostCommentCountById = $dbUser->getPostCommentCountById($userPostId);
                                    if($getPostCommentCountById > 5){
                                        ?>
                                        <div class="row">
                                            <div class="col-lg mb-3">
                                                <a href="" class="view-more-comment">View more comments</a>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                ?>
                            </div>
                        </form>
                        <div id="<?php echo "commentTextArea".$userPostId; ?>" class="row">
                            <div class="col-2">
                                <?php
                                //for comment textarea 
                                if(isset($_SESSION["loginuser"])){
                                    $data2 = $dbUser->getUserProfileImageById($userId);
                                    foreach($data2 as $row2){
                                        $userProfileImage = $row2["user_image"];
                                        ?>
                                        <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId; ?>">
                                            <img class="profile-image-small" src="<?php echo "./images/user/$userProfileImage"; ?>"/>
                                        </a>
                                        <?php
                                    }
                                }
                                else{
                                    ?>
                                    <img class="profile-image-small" src="<?php echo "./images/system/anonymous.png"; ?>"/>
                                    <?php
                                }
                                ?>
                            </div>
                            <div class="col-lg mb-3">
                                <form class="post-comment">
                                    <input class="user-post-id" type="hidden" name="userPostId" value="<?php echo $userPostId; ?>"/>
                                    <input class="comment-box-id" type="hidden" name="commentBoxId" value="<?php echo $userPostId; ?>"/>
                                    <textarea class="form-control post-comment" placeholder="Write a comment..." name="postComment" style="height:10px;"></textarea>
                                </form>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
        <?php

    }
}
if(isset($_POST["viewMoreCommentById"])){
    $userPostId = $_POST["userPostId"];
    $start = $_POST["start"];
    $limit = $_POST["limit"];
    $userId = $_POST["userId"];
    $data = $dbUser->viewMoreCommentById($userPostId,$start,$limit);
    foreach($data as $row){
        $userCommentId = $row["user_comment_id"];
        $userCommentatorId = $row["user_id"];
        $userComment = $row["user_comment"];
        $userCommentDate = $row["user_comment_date"];
        $userCommentTime = $row["user_comment_time"];
        $userImage2 = $row["user_image"];
        $userDisplayName = $row["user_display_name"]; 
        $dateTime2 = $userCommentDate. " ".$userCommentTime;
        ?>
        <div id="userCommentId<?php echo $userCommentId; ?>" class="container mb-3 comment-box-color">
            <div class="row">
                <div class="col-2">
                    <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId;?>">
                    <img class="profile-image-small" src="<?php if($userImage2 != ""){echo "./images/user/$userImage2"; }else{echo "./images/system/anonymous.png"; }?>"/></a>
                </div>
                <div class="col-lg mb-3">
                    <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId; ?>"><h6><?php if($userCommentatorId != 0){echo $userDisplayName; }else{echo "<span class='text-danger'>Anonymous</span>";}?></h6></a>
                    <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId; ?>"><span class="badge bg-success"><span class = "fs-13"><?php echo time_ago($dateTime2); ?></span></span></a>
                </div>
            </div>
            <div class="row">
                <div class="col-lg mb-3">
                    <p class="text-center">
                        <?php echo $userComment; ?>
                    </p>
                </div>
                <?php
                $userPostUserId = 0;
                $data3 = $dbUser->getUserIdByUserPostId($userPostId);
                foreach($data3 as $row3){
                    $userPostUserId = $row3["user_id"];
                }
                if($userId == $userCommentatorId && $userId != 0 || $userId == $userPostUserId){
                    ?>
                    <div class="col text-end">
                        <div class="dropdown">
                            <button class="btn bg-primary text-white dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="iconify" data-icon="entypo:dots-three-horizontal"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                <li>
                                    <form class="remove-comment">
                                        <input class="user-comment-id" type="hidden" value="<?php echo $userCommentId; ?>"/>
                                        
                                    <a id="" class="dropdown-item remove-comment">Remove Comment</a>
                                    </form>
                                
                                </li>
                            </ul>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
    }
}
if(isset($_POST["insertPostComment"])){
    $userId = $_POST["userId"];
    $userPostId = $_POST["userPostId"];
    $postComment = $_POST["postComment"];
 
    $dateToday = date("F j, Y");
    $time = date("g:i a");
    $isSendNotification = $dbUser->insertCommentWithNotification($userId,$userPostId,$postComment,$dateToday,$time);
    $options = array(
        'cluster' => 'ap1',
        'useTLS' => true
    );
    $pusher = new Pusher\Pusher(
        'd2e24ff059b1db0ad84f',
        '06b24f6830930b4936c3',
        '1271545',
        $options
    );
    if($isSendNotification == "1"){
        $data['message'] = $userId." ".$userPostId;
        $pusher->trigger('my-user-notification', 'my-user-notification-event', $data);
        $pusher->trigger('my-user-notification-container', 'my-user-notification-container-event', $data);

    }
    $data['user_post_id'] = $userPostId;
    $data['comment_box_id_number'] = $userPostId;
    $pusher->trigger('comment-box-id-number', 'comment-box-id-number-event', $data);
}
if(isset($_POST["getPostCommentById"])){
    $userPostId = $_POST["userPostId"];
    $userId = $_POST["userId"];
    //for user comment
    $data2 = $dbUser->getPostCommentById($userPostId);
    foreach($data2 as $row2){
        $userCommentId = $row2["user_comment_id"];
        $userCommentatorId = $row2["user_id"];
        $userComment = $row2["user_comment"];
        $userCommentDate = $row2["user_comment_date"];
        $userCommentTime = $row2["user_comment_time"];
        $userImage2 = $row2["user_image"];
        $userDisplayName = $row2["user_display_name"]; 
        $dateTime2 = $userCommentDate. " ".$userCommentTime;
        ?>
        <div id="userCommentId<?php echo $userCommentId; ?>" class="container mb-3 comment-box-color">
            <div class="row">
                <div class="col-2">
                    <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId;?>">
                    <img class="profile-image-small" src="<?php if($userImage2 != ""){echo "./images/user/$userImage2"; }else{echo "./images/system/anonymous.png"; }?>"/></a>
                </div>
                <div class="col-lg mb-3">
                    <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId; ?>"><h6><?php if($userCommentatorId != 0){echo $userDisplayName; }else{echo "<span class='text-danger'>Anonymous</span>";}?></h6></a>
                    <a class="" href="./profile.php?profile_id=<?php echo $userCommentatorId; ?>"><span class="badge bg-success"><span class = "fs-13"><?php echo time_ago($dateTime2); ?></span></span></a>
                </div>
            </div>
            <div class="row">
                <div class="col-lg mb-3">
                    <p class="text-center">
                        <?php echo $userComment; ?>
                    </p>
                </div>
                <?php
                $userPostUserId = 0;
                $data3 = $dbUser->getUserIdByUserPostId($userPostId);
                foreach($data3 as $row3){
                    $userPostUserId = $row3["user_id"];
                }
                if($userId == $userCommentatorId && $userId != 0 || $userId == $userPostUserId){
                    ?>
                    <div class="col text-end">
                        <div class="dropdown">
                            <button class="btn bg-primary text-white dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="iconify" data-icon="entypo:dots-three-horizontal"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                <li>
                                    <form class="remove-comment">
                                        <input class="user-comment-id" type="hidden" value="<?php echo $userCommentId; ?>"/>
                                        
                                    <a id="" class="dropdown-item remove-comment">Remove Comment</a>
                                    </form>
                                    
                                </li>
                            </ul>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
    }
}
if(isset($_POST["removePostById"])){
    $userPostId = $_POST["userPostId"];
    $userId = $_POST["userId"];
    echo $dbUser->removePostById($userPostId,$userId);
}
if(isset($_POST["removeCommentById"])){
    $userCommentId = $_POST["userCommentId"];
    echo $dbUser->removeCommentById($userCommentId);
}
?>
