<footer>
    <div class = "container-fluid mt-5 container-footer">
        <div class = "row justify-content-center">
            <div class = "col-md-8 text-center">
                <p class="text-left text-white">@ 2022 All rights reserved.</p>
            </div>
            <!-- <div class = "col-md-4 text-center">
                <?php
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                if(isset($_SESSION["logintype"]) && $_SESSION["logintype"] != "none"){
                    ?>
                    <img class="img-fluid" src="../images/system/logo.png" style="width:200px; height:200px; border-radius: 50%;"/>
                    <?php
                }
                else{
                    ?>
                    <img class="img-fluid" src="./images/system/logo.png" style="width:200px; height:200px; border-radius: 50%;"/>
                    <?php
                }
                ?>
                
            </div> -->
        </div>
    </div>
</footer>